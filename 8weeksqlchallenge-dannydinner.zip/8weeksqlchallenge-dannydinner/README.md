# Danny Dinner
Week 1 SQL Challenge from datawithdanny.com

https://8weeksqlchallenge.com/case-study-1/

Danny wants to use the data to answer a few simple questions about his customers, especially about their visiting patterns, how much money they’ve spent and also which menu items are their favourite. Having this deeper connection with his customers will help him deliver a better and more personalised experience for his loyal customers.
