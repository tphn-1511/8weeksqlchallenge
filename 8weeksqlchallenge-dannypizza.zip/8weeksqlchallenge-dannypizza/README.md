Case study #2 - Pizza Runner

https://8weeksqlchallenge.com/case-study-2/

